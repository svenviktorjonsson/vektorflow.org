# [Vektor Flow](https://vektorflow.org/)

Vektor Flow (VKF) is a statically typed, expression-oriented compiled language
for numerical computing, simulations, symbolic mathematics, and visual programs.
Values retain type, shape, axis, unit, and effect information so the compiler
can validate and optimize work without exposing implementation machinery in
source code.

VKF is experimental software with unstable APIs and syntax. Do not use it for
production or run untrusted native programs.

## Learn

Start with editable programs, then build a mental model of values, scopes,
functions, and compiler decisions. The [Learn](docs/site/learn.md) page links
the runnable introduction and the complete guide.

## Language

VKF is immutable by default. Functions lift through compatible structures,
named suffix axes align data by meaning, and units participate in static type
checking.

<!-- live-example: examples/introduction/vector-functions.vkf -->

The [Language](docs/site/language.md) page links the concepts, syntax,
standard-library, and style references.

## Build

Native compilers produce executables directly. The browser compiler runs the
supported subset locally through WebAssembly. Visual programs use the same
typed values as numerical code, while explicit concurrency coordinates event
and I/O work separately from automatic numeric scheduling.

The [Build](docs/site/build.md) page links installation, browser embedding,
editor integration, testing, and complete examples.

## Results

Performance claims are release-, platform-, workload-, and peer-specific.
Published tables compare VKF with C++, Rust, and Zig and use `—` for unmeasured
cells. Current native packages cover Windows x64 and Linux x64; browser
WebAssembly is published separately, and no macOS compiler is included.

The [Results](docs/site/results.md) page links measurements, methodology, and
validation evidence.

## About

VKF is moving toward a self-hosted compiler and device-aware lowering without
changing the source model into a collection of backend commands. Those plans
are not claims about the current compiler.

The [About](docs/site/about.md) page links the roadmap, origins, architecture,
and source repository.

[Releases](RELEASES.md) explains the release process and what changed between
stable versions. Before 1.0, the public site offers only the latest stable
compiler. From 1.0, it keeps the newest patch for each `x.y` line.
