# [Vektor Flow](https://vektorflow.org/)

Vektor Flow (VKF) is a statically typed, expression-oriented compiled language
for numerical computing, simulations, symbolic mathematics, and visual
programs. Values are immutable by default, functions lift through structures,
and named suffix axes let source code retain the shape and meaning of data.

Version 0.4.7 is available for Windows x64, Linux x64, and browser WebAssembly.
This release does not include a macOS compiler. Its performance page publishes
local Windows and Linux comparisons with C++, Rust, and Zig, plus Firefox
WebAssembly peer and same-host native comparisons; unmeasured cells are marked
`—`. VKF is experimental software with unstable APIs and syntax; do not use it
for production or run untrusted native VKF programs.

## Why VKF

VKF keeps structural information in the language instead of reconstructing it
after parsing. Types, dimensions, units, axes, and effects remain available to
the compiler for validation and optimization.

- Values are immutable unless an existing binding is updated explicitly.
- Functions apply to scalars and lift through compatible vector structure.
- Named suffix axes align data by label rather than by position alone.
- Statistical and analytical operations select axes at compile time.
- Physical dimensions and preferred display units are checked statically.
- Lazy evaluation is demand-backed and deterministic.
- Ordinary numeric parallelism is a compiler decision; event and I/O
  concurrency is explicit through `.concurrent`.
- Native compilers emit executables directly, without invoking a C++ compiler,
  assembler, linker, or Python at user compile time.

## Language at a glance

Declarations use `name:value`. Updating an existing binding uses `.name:value`.
The final expression is the result of a function, and `::` writes a value.

### Scalar lifting

```vkf
square(x): x*x
values: [1, 2, 3, 4]
:: square(values)
```

Named axes are attached to values. An operation such as `stat.mean_j` reduces
the `j` axis and keeps the remaining structure.

### Axis reduction

```vkf
stat: .stat

values: [[1, 2, 3], [4, 5, 6]]_ij
:: stat.mean_j(values)
```

Attached suffixes also express ordered dimensions directly: `value_a` and
`value_aq` have the same structure as `value->a` and `value->aq`. Exact ordinary
identifiers containing underscores take precedence. Compile-time suffix
parameters, fixed and computed multidimensional indices, preserved dimensions,
and coordinate spreading are described in the
[language guide](docs/language-guide.md).

Units are part of the type system. Compatible arithmetic stores canonical SI
magnitudes while preserving the left operand's preferred display unit.

### Unit conversion

```vkf
:.units.si

:: 2m + 30cm
:: (2m).to(cm)
```

## Statistics, symbolic work, and linear algebra

The standard library includes axis-aware reductions, interpolation, symbolic
differentiation and integration, dense linear algebra, deterministic random
generation, physical units, time, I/O, collections, regular expressions, and
UI construction.

Suffix-selected functions include forms such as:

- `stat.sum_j(values_ij)` and `stat.mean_i(values_ij)`;
- `stat.interp_i(values_i, i_to)` for index-space interpolation;
- `stat.interp_i(values_i, i, i_to)` for sampled coordinates;
- `symbolic.deriv_x(value)` and `symbolic.integ_x(value)`.

Bounds and steps follow the selected axis. Reversed integral limits negate the
result, and incompatible sum bounds produce an empty sum. See the
[standard-library reference](docs/standard-library.md) for the complete current
surface and its native/browser boundaries.

## Visual programs

VKF can describe plots, cameras, screens, retained scenes, colormaps, and UI
views with the same typed values used by numerical code.

### Retained plot

```vkf
: .ui.display
:.math

display: Display()
frame: display.add_frame(pos:[0.08, 0.08], size:[0.84, 0.84])
x: 0.025*[0..400] - 5

frame.add(x_i:x, y_i:sin(x), color_by:"y", colormap:"viridis")
display.show()
```

The browser guide compiles supported programs locally to WebAssembly. Native
visual applications use the packaged runtime and run with the current user's
permissions.

## Concurrency and execution

`.command` runs serial operating-system commands. `.concurrent.process` starts
an ordinary VKF worker, while queues, broadcasts, and shared values coordinate
events and I/O. This API is separate from automatic numeric scheduling.

### Worker queue

```vkf
concurrent: .concurrent

worker(events, state):
    (event:events.get())??>
        0 => state
        worker(events, state)

events: concurrent.queue()
state: concurrent.shared((mode:"run", samples:[1,2,3]))
task: concurrent.process(worker, events, state)
events.put(0)
:: task.join()
```

The 0.4.7 packages verify native worker argument binding, isolated processes,
result-returning joins, forced termination, FIFO queues, broadcast fan-out, and
shared bulk values on Windows x64 and Linux x64. The browser runtime provides
the corresponding Worker/SharedArrayBuffer path when cross-origin isolation is
available.

## Install and run

Download 0.4.7 from the [installation page](INSTALL.md). Native packages are
published for Windows x64 and Linux x64; the browser compiler is also published
as a versioned WebAssembly package. macOS is not shipped in 0.4.7.

### Command line

```console
vkf program.vkf                 build when changed, then run
vkf program.vkf -o app         build or reuse a named executable, then run
vkf -b program.vkf             build without running
vkf -e ':: 2 + 2'              evaluate inline source
vkf -t tests                   run native tests in a file or directory
vkf -v                         print the compiler version
```

Start with the [runnable guide](https://vektorflow.org/guide.html) or browse the
[examples](examples). The most useful references are:

- [Language guide](docs/language-guide.md)
- [Standard library](docs/standard-library.md)
- [Installation and CLI](INSTALL.md)
- [Testing](TESTING.md)
- [Browser embedding](docs/site/browser.md)
- [Performance and benchmark receipts](docs/site/performance.md)
- [VS Code integration](vscode/README.md)
- [0.4.7 release notes](docs/releases/0.4.7.md)
- [Release history](RELEASES.md)

## Release scope

0.4.7 ships correctness-tested Windows x64, Linux x64, and browser WebAssembly
artifacts and no macOS compiler. Version-matched local benchmarks cover four of
the five established native workloads on Windows x64 and Linux x64 against
C++, Rust, and Zig. Firefox compares VKF WebAssembly with C++, Rust, and Zig
WebAssembly and with native VKF on the same Windows host. The combined-parallel,
macOS, Chrome, Safari, linear-algebra, and symbolic cells remain visible as `—`
because they were not measured for this release. Historical evidence remains
attached to the releases that produced it.

CUDA and WebGPU device planning for suffix-aware tensor contractions is future
work. The current compiler does not claim automatic TensorFlow-style GPU
acceleration.
