// Generated feature-specialized retained-scene renderer
struct SceneCamera {
  view_projection: mat4x4<f32>,
  light_view_projection: array<mat4x4<f32>, 6>,
  shadow_near_far: array<vec4<f32>, 6>,
  mirror_view_projection: array<mat4x4<f32>, 2>,
  mirror_view_position: array<vec4<f32>, 2>,
  mirror_view_target: array<vec4<f32>, 2>,
  view_position: vec4<f32>,
  ambient: vec4<f32>,
};
@group(0) @binding(0) var<uniform> scene: SceneCamera;

struct SceneLight {
  position_and_range: vec4<f32>,
  color_and_intensity: vec4<f32>,
  target_and_radius: vec4<f32>,
  kind_and_shadow: vec4<f32>,
  aperture_float_offset: u32,
  aperture_vertex_count: u32,
  aperture_vertex_stride_floats: u32,
  aperture_object_index: u32,
  polarization: vec4<f32>,
  polarization_basis: vec4<f32>,
};
@group(0) @binding(1) var<storage, read> lights: array<SceneLight>;
const VKF_LIGHT_COUNT: u32 = 6u;
@group(0) @binding(2) var shadow_depth: texture_depth_2d_array;
@group(0) @binding(3) var shadow_sampler: sampler_comparison;

fn vkf_light_attenuation(
  distance: f32,
  intensity: f32,
  range: f32,
) -> f32 {
  let inverse_square = intensity / max(distance * distance, 1.0e-6);
  if (range <= 1.0e-6) {
    return inverse_square;
  }
  if (distance >= range) {
    return 0.0;
  }
  let range_ratio = clamp(distance / range, 0.0, 1.0);
  let fade = 1.0 - range_ratio * range_ratio;
  return inverse_square * fade * fade;
}

const VKF_AREA_LIGHT_SAMPLE_COUNT: u32 = 8u;
const VKF_AREA_LIGHT_DISK: array<vec2<f32>, 8> = array<vec2<f32>, 8>(
  vec2<f32>(0.353553, 0.000000),
  vec2<f32>(-0.353553, 0.000000),
  vec2<f32>(0.000000, 0.612372),
  vec2<f32>(0.000000, -0.612372),
  vec2<f32>(0.559017, 0.559017),
  vec2<f32>(-0.559017, -0.559017),
  vec2<f32>(-0.661438, 0.661438),
  vec2<f32>(0.661438, -0.661438)
);

fn vkf_transport_safe_normalize(value: vec3<f32>) -> vec3<f32> {
  return value / max(length(value), 1.0e-12);
}

fn vkf_sample_area_light_transport(
  world_position: vec3<f32>,
  light: SceneLight,
) -> vec4<f32> {
  let source_normal = vkf_transport_safe_normalize(
    light.target_and_radius.xyz - light.position_and_range.xyz);
  let basis_hint = select(
    vec3<f32>(0.0, 0.0, 1.0),
    vec3<f32>(0.0, 1.0, 0.0),
    abs(source_normal.z) > 0.9);
  let basis_x = vkf_transport_safe_normalize(cross(
    basis_hint, source_normal));
  let basis_y = cross(source_normal, basis_x);
  var weighted_direction = vec3<f32>(0.0);
  var attenuation_sum = 0.0;
  for (var sample_index = 0u;
       sample_index < VKF_AREA_LIGHT_SAMPLE_COUNT;
       sample_index = sample_index + 1u) {
    let sample_offset = VKF_AREA_LIGHT_DISK[sample_index];
    let sample_position = light.position_and_range.xyz +
      (basis_x * sample_offset.x + basis_y * sample_offset.y) *
      light.target_and_radius.w;
    let to_sample = sample_position - world_position;
    let sample_attenuation = vkf_light_attenuation(
      length(to_sample),
      light.color_and_intensity.w,
      light.position_and_range.w);
    weighted_direction = weighted_direction +
      vkf_transport_safe_normalize(to_sample) * sample_attenuation;
    attenuation_sum = attenuation_sum + sample_attenuation;
  }
  return vec4<f32>(
    vkf_transport_safe_normalize(weighted_direction),
    attenuation_sum / f32(VKF_AREA_LIGHT_SAMPLE_COUNT));
}

fn vkf_sample_light_transport(
  world_position: vec3<f32>,
  light: SceneLight,
  centroid_vector: vec3<f32>,
) -> vec4<f32> {
  if (u32(light.kind_and_shadow.x) == 5u) {
    return vkf_sample_area_light_transport(world_position, light);
  }
  return vec4<f32>(
    vkf_transport_safe_normalize(centroid_vector),
    vkf_light_attenuation(
      length(centroid_vector),
      light.color_and_intensity.w,
      light.position_and_range.w));
}

const VKF_FINAL_MIDDLE_GRAY: f32 = 0.18;

fn vkf_final_camera_response(linear_radiance: vec3<f32>) -> vec3<f32> {
  let exposed = max(linear_radiance, vec3<f32>(0.0)) / VKF_FINAL_MIDDLE_GRAY;
  return exposed / (vec3<f32>(1.0) + exposed);
}
const VKF_MAX_REFLECTION_DEPTH: u32 = 2u;
const VKF_BACKGROUND_RADIANCE: vec4<f32> = vec4<f32>(0.01200000, 0.01800000, 0.03200000, 1.00000000);
@group(0) @binding(4) var planar_reflection_texture: texture_2d<f32>;
@group(0) @binding(5) var planar_reflection_sampler: sampler;

struct FinalPresentVertexOut {
  @builtin(position) clip_position: vec4<f32>,
  @location(0) uv: vec2<f32>,
};

@vertex
fn vkf_present_vertex(
  @builtin(vertex_index) vertex_index: u32,
) -> FinalPresentVertexOut {
  var out: FinalPresentVertexOut;
  let x = select(-1.0, 3.0, vertex_index == 1u);
  let y = select(-1.0, 3.0, vertex_index == 2u);
  out.clip_position = vec4<f32>(x, y, 0.0, 1.0);
  out.uv = vec2<f32>(x * 0.5 + 0.5, 0.5 - y * 0.5);
  return out;
}

@fragment
fn vkf_present_fragment(
  input: FinalPresentVertexOut,
) -> @location(0) vec4<f32> {
  let linear = textureSampleLevel(
    planar_reflection_texture, planar_reflection_sampler,
    input.uv, 0.0);
  return vec4<f32>(vkf_final_camera_response(linear.rgb), linear.a);
}
struct PassState {
  camera_state_index: u32,
  reflection_depth: u32,
  light_index: u32,
  target_layer: u32,
  object_index: u32,
  aperture_float_offset: u32,
  aperture_vertex_count: u32,
  aperture_vertex_stride_floats: u32,
};
@group(0) @binding(6) var<uniform> pass_state: PassState;

struct ObjectMaterial {
  model: mat4x4<f32>,
  normal_matrix: mat4x4<f32>,
  base_color: vec4<f32>,
  checker_color_a: vec4<f32>,
  checker_color_b: vec4<f32>,
  checker_scale: vec2<f32>,
  reflectivity: f32,
  texture_kind: u32,
  receives_shadow: u32,
  reflection_depth: u32,
  roughness: f32,
  specular_strength: f32,
  no_backface_specular: u32,
  surface_kind: u32,
  reflection_camera_index: u32,
  object_index: u32,
  ior: f32,
  extinction: f32,
};
@group(1) @binding(0) var<uniform> object: ObjectMaterial;

struct ViewportInput {
  width: f32,
  height: f32,
};
@group(2) @binding(0) var<storage, read> raw_camera: array<f32>;
@group(2) @binding(1) var<storage, read> raw_lights: array<f32>;
@group(2) @binding(2) var<storage, read> raw_objects: array<f32>;
@group(2) @binding(3) var<storage, read> aperture_vertices: array<f32>;
@group(2) @binding(4) var<uniform> viewport: ViewportInput;

struct DerivedObjectSlot {
  @size(256) value: ObjectMaterial,
};
@group(3) @binding(0) var<storage, read_write> derived_scene: SceneCamera;
@group(3) @binding(1) var<storage, read_write> derived_lights: array<SceneLight>;
@group(3) @binding(2) var<storage, read> derived_objects: array<DerivedObjectSlot>;
@group(3) @binding(3) var<storage, read_write> derived_objects_write: array<DerivedObjectSlot>;

const VKF_OBJECT_COUNT: u32 = 5u;
const VKF_DIRECT_SHADOW_BOUNDS_MIN: vec3<f32> = vec3<f32>(-0.23999999, 0.03200000, -0.18000001);
const VKF_DIRECT_SHADOW_BOUNDS_MAX: vec3<f32> = vec3<f32>(0.23999999, 0.23999999, 0.41999999);
fn vkf_object_local_bounds_min(object_index: u32) -> vec3<f32> {
  if (object_index == 0u) { return vec3<f32>(-0.23999999, 0.03200000, -0.18000001); }
  if (object_index == 1u) { return vec3<f32>(-0.19000000, 0.03200000, 0.25000000); }
  if (object_index == 2u) { return vec3<f32>(-0.09468990, 0.03298740, -0.06187360); }
  if (object_index == 3u) { return vec3<f32>(-0.09899500, 0.23999999, -0.01656900); }
  if (object_index == 4u) { return vec3<f32>(0.09899500, 0.23999999, 0.09656900); }
  return vec3<f32>(0.0);
}
fn vkf_object_local_bounds_max(object_index: u32) -> vec3<f32> {
  if (object_index == 0u) { return vec3<f32>(0.23999999, 0.03200000, 0.41999999); }
  if (object_index == 1u) { return vec3<f32>(0.19000000, 0.23999999, 0.25000000); }
  if (object_index == 2u) { return vec3<f32>(0.06100910, 0.18732101, 0.05879970); }
  if (object_index == 3u) { return vec3<f32>(-0.09899500, 0.23999999, -0.01656900); }
  if (object_index == 4u) { return vec3<f32>(0.09899500, 0.23999999, 0.09656900); }
  return vec3<f32>(0.0);
}
fn vkf_object_has_local_bounds(object_index: u32) -> bool {
  if (object_index == 0u) { return true; }
  if (object_index == 1u) { return true; }
  if (object_index == 2u) { return true; }
  if (object_index == 3u) { return true; }
  if (object_index == 4u) { return true; }
  return false;
}
fn vkf_object_contributes_shadow_bounds(object_index: u32) -> bool {
  if (object_index == 3u) { return false; }
  if (object_index == 4u) { return false; }
  return vkf_object_has_local_bounds(object_index);
}


fn vkf_safe_normalize(value: vec3<f32>) -> vec3<f32> {
  return value * inverseSqrt(max(dot(value, value), 1.0e-12));
}

fn vkf_adaptive_shadow_up(direction: vec3<f32>) -> vec3<f32> {
  let unit_direction = vkf_safe_normalize(direction);
  return select(
    vec3<f32>(0.0, 1.0, 0.0),
    vec3<f32>(0.0, 0.0, 1.0),
    abs(unit_direction.y) > 0.98
  );
}

fn vkf_polarization_axis(
  propagation: vec3<f32>,
  basis_hint: vec3<f32>,
) -> vec3<f32> {
  let k = vkf_safe_normalize(propagation);
  let projected = basis_hint - k * dot(basis_hint, k);
  let fallback_hint = select(
    vec3<f32>(0.0, 0.0, 1.0),
    vec3<f32>(1.0, 0.0, 0.0),
    abs(k.z) > 0.9
  );
  let fallback = fallback_hint - k * dot(fallback_hint, k);
  return vkf_safe_normalize(select(
    projected, fallback, dot(projected, projected) < 1.0e-10));
}

fn vkf_rotate_stokes_basis(
  polarization: vec4<f32>,
  propagation: vec3<f32>,
  from_basis_hint: vec3<f32>,
  to_basis_hint: vec3<f32>,
) -> vec4<f32> {
  let k = vkf_safe_normalize(propagation);
  let from_axis = vkf_polarization_axis(k, from_basis_hint);
  let to_axis = vkf_polarization_axis(k, to_basis_hint);
  let perpendicular_axis = cross(k, from_axis);
  let cosine = clamp(dot(from_axis, to_axis), -1.0, 1.0);
  let sine = clamp(dot(perpendicular_axis, to_axis), -1.0, 1.0);
  let cos_double = cosine * cosine - sine * sine;
  let sin_double = 2.0 * cosine * sine;
  return vec4<f32>(
    polarization.x,
    polarization.y * cos_double + polarization.z * sin_double,
    -polarization.y * sin_double + polarization.z * cos_double,
    polarization.w
  );
}

fn vkf_look_at(
  eye: vec3<f32>,
  focus_point: vec3<f32>,
  up_hint: vec3<f32>,
) -> mat4x4<f32> {
  let z_axis = vkf_safe_normalize(eye - focus_point);
  let x_axis = vkf_safe_normalize(cross(up_hint, z_axis));
  let y_axis = cross(z_axis, x_axis);
  return mat4x4<f32>(
    vec4<f32>(x_axis.x, y_axis.x, z_axis.x, 0.0),
    vec4<f32>(x_axis.y, y_axis.y, z_axis.y, 0.0),
    vec4<f32>(x_axis.z, y_axis.z, z_axis.z, 0.0),
    vec4<f32>(-dot(x_axis, eye), -dot(y_axis, eye), -dot(z_axis, eye), 1.0)
  );
}

fn vkf_perspective(
  fov_y_radians: f32,
  aspect: f32,
  near_plane: f32,
  far_plane: f32,
) -> mat4x4<f32> {
  let focal = 1.0 / tan(fov_y_radians * 0.5);
  let depth = far_plane / (near_plane - far_plane);
  return mat4x4<f32>(
    vec4<f32>(focal / max(aspect, 1.0e-6), 0.0, 0.0, 0.0),
    vec4<f32>(0.0, focal, 0.0, 0.0),
    vec4<f32>(0.0, 0.0, depth, -1.0),
    vec4<f32>(0.0, 0.0, near_plane * depth, 0.0)
  );
}

fn vkf_reflect_point(
  point: vec3<f32>,
  plane_point: vec3<f32>,
  plane_normal: vec3<f32>,
) -> vec3<f32> {
  return point - 2.0 * dot(point - plane_point, plane_normal) * plane_normal;
}

fn vkf_reflect_direction(
  direction: vec3<f32>,
  plane_normal: vec3<f32>,
) -> vec3<f32> {
  return direction - 2.0 * dot(direction, plane_normal) * plane_normal;
}

fn vkf_flip_clip_x() -> mat4x4<f32> {
  return mat4x4<f32>(
    vec4<f32>(-1.0, 0.0, 0.0, 0.0),
    vec4<f32>(0.0, 1.0, 0.0, 0.0),
    vec4<f32>(0.0, 0.0, 1.0, 0.0),
    vec4<f32>(0.0, 0.0, 0.0, 1.0)
  );
}

fn vkf_scale_matrix(scale: vec3<f32>) -> mat4x4<f32> {
  return mat4x4<f32>(
    vec4<f32>(scale.x, 0.0, 0.0, 0.0),
    vec4<f32>(0.0, scale.y, 0.0, 0.0),
    vec4<f32>(0.0, 0.0, scale.z, 0.0),
    vec4<f32>(0.0, 0.0, 0.0, 1.0)
  );
}

fn vkf_translation_matrix(offset: vec3<f32>) -> mat4x4<f32> {
  return mat4x4<f32>(
    vec4<f32>(1.0, 0.0, 0.0, 0.0),
    vec4<f32>(0.0, 1.0, 0.0, 0.0),
    vec4<f32>(0.0, 0.0, 1.0, 0.0),
    vec4<f32>(offset, 1.0)
  );
}

fn vkf_rotation_matrix(degrees: vec3<f32>) -> mat4x4<f32> {
  let radians = degrees * 0.017453292519943295;
  let cx = cos(radians.x);
  let sx = sin(radians.x);
  let cy = cos(radians.y);
  let sy = sin(radians.y);
  let cz = cos(radians.z);
  let sz = sin(radians.z);
  let rotation_x = mat4x4<f32>(
    vec4<f32>(1.0, 0.0, 0.0, 0.0),
    vec4<f32>(0.0, cx, sx, 0.0),
    vec4<f32>(0.0, -sx, cx, 0.0),
    vec4<f32>(0.0, 0.0, 0.0, 1.0)
  );
  let rotation_y = mat4x4<f32>(
    vec4<f32>(cy, 0.0, -sy, 0.0),
    vec4<f32>(0.0, 1.0, 0.0, 0.0),
    vec4<f32>(sy, 0.0, cy, 0.0),
    vec4<f32>(0.0, 0.0, 0.0, 1.0)
  );
  let rotation_z = mat4x4<f32>(
    vec4<f32>(cz, sz, 0.0, 0.0),
    vec4<f32>(-sz, cz, 0.0, 0.0),
    vec4<f32>(0.0, 0.0, 1.0, 0.0),
    vec4<f32>(0.0, 0.0, 0.0, 1.0)
  );
  return rotation_z * rotation_y * rotation_x;
}

fn vkf_aperture_position(vertex_index: u32) -> vec3<f32> {
  let base = pass_state.aperture_float_offset +
    vertex_index * pass_state.aperture_vertex_stride_floats;
  let local_position = vec3<f32>(
    aperture_vertices[base],
    aperture_vertices[base + 1u],
    aperture_vertices[base + 2u]
  );
  return (derived_objects[pass_state.object_index].value.model *
    vec4<f32>(local_position, 1.0)).xyz;
}

fn vkf_aperture_near_plane(
  view: mat4x4<f32>,
  near_hint: f32,
) -> f32 {
  var aperture_distance = 1.0e30;
  for (var vertex_index = 0u;
       vertex_index < pass_state.aperture_vertex_count;
       vertex_index = vertex_index + 1u) {
    let camera_vertex = view * vec4<f32>(
      vkf_aperture_position(vertex_index), 1.0);
    aperture_distance = min(
      aperture_distance, max(-camera_vertex.z, 1.0e-4));
  }
  return max(near_hint, aperture_distance - 1.0e-3);
}

fn vkf_off_axis_projection(
  view: mat4x4<f32>,
  near_hint: f32,
  far_plane: f32,
) -> mat4x4<f32> {
  let near_plane = vkf_aperture_near_plane(view, near_hint);
  var min_x = 1.0e30;
  var max_x = -1.0e30;
  var min_y = 1.0e30;
  var max_y = -1.0e30;
  for (var vertex_index = 0u;
       vertex_index < pass_state.aperture_vertex_count;
       vertex_index = vertex_index + 1u) {
    let camera_vertex = view * vec4<f32>(
      vkf_aperture_position(vertex_index), 1.0);
    let scale = near_plane / max(-camera_vertex.z, 1.0e-4);
    min_x = min(min_x, camera_vertex.x * scale);
    max_x = max(max_x, camera_vertex.x * scale);
    min_y = min(min_y, camera_vertex.y * scale);
    max_y = max(max_y, camera_vertex.y * scale);
  }
  let width = max(max_x - min_x, 1.0e-5);
  let height = max(max_y - min_y, 1.0e-5);
  let depth = far_plane / (near_plane - far_plane);
  return mat4x4<f32>(
    vec4<f32>(2.0 * near_plane / width, 0.0, 0.0, 0.0),
    vec4<f32>(0.0, 2.0 * near_plane / height, 0.0, 0.0),
    vec4<f32>((max_x + min_x) / width,
      (max_y + min_y) / height, depth, -1.0),
    vec4<f32>(0.0, 0.0, near_plane * depth, 0.0)
  );
}

fn vkf_shadow_slot(light_index: u32) -> i32 {
  if (light_index == 0u) { return 0; }
  if (light_index == 1u) { return 1; }
  if (light_index == 2u) { return 2; }
  if (light_index == 3u) { return 3; }
  if (light_index == 4u) { return 4; }
  if (light_index == 5u) { return 5; }
  return -1;
}
fn vkf_shadow_receiver_light_mask(receiver_object_index: u32) -> u32 {
  return 63u;
}
fn vkf_shadow_view_count(light_index: u32) -> u32 {
  if (light_index == 0u) { return 1u; }
  if (light_index == 1u) { return 1u; }
  if (light_index == 2u) { return 1u; }
  if (light_index == 3u) { return 1u; }
  if (light_index == 4u) { return 1u; }
  if (light_index == 5u) { return 1u; }
  return 0u;
}
fn vkf_reflection_camera_slot(object_index: u32) -> u32 {
  if (object_index == 0u) { return 0u; }
  if (object_index == 1u) { return 1u; }
  return 0xffffffffu;
}
fn vkf_reflection_parent_slot(camera_index: u32) -> u32 {
  return 0xffffffffu;
}
fn vkf_next_reflection_camera_slot(
  camera_index: u32, object_index: u32,
) -> u32 {
  return 0xffffffffu;
}


struct VkfDirectShadowBounds {
  minimum: vec3<f32>,
  maximum: vec3<f32>,
};

fn vkf_scene_transform_revision() -> u32 {
  var transform_revision = 2166136261u;
  for (var object_index = 0u;
       object_index < VKF_OBJECT_COUNT;
       object_index = object_index + 1u) {
    let base = object_index * 32u;
    for (var field_index = 0u; field_index < 9u;
         field_index = field_index + 1u) {
      transform_revision =
        (transform_revision ^ bitcast<u32>(raw_objects[base + field_index])) *
        16777619u;
    }
  }
  return transform_revision;
}

fn vkf_refit_direct_shadow_bounds() -> VkfDirectShadowBounds {
  var minimum = vec3<f32>(1.0e30);
  var maximum = vec3<f32>(-1.0e30);
  var point_count = 0u;
  for (var object_index = 0u;
       object_index < VKF_OBJECT_COUNT;
       object_index = object_index + 1u) {
    if (!vkf_object_contributes_shadow_bounds(object_index)) {
      continue;
    }
    let local_minimum = vkf_object_local_bounds_min(object_index);
    let local_maximum = vkf_object_local_bounds_max(object_index);
    let model = derived_objects[object_index].value.model;
    for (var corner_index = 0u; corner_index < 8u;
         corner_index = corner_index + 1u) {
      let local_corner = vec3<f32>(
        select(local_minimum.x, local_maximum.x,
          (corner_index & 1u) != 0u),
        select(local_minimum.y, local_maximum.y,
          (corner_index & 2u) != 0u),
        select(local_minimum.z, local_maximum.z,
          (corner_index & 4u) != 0u)
      );
      let world_corner = (model * vec4<f32>(local_corner, 1.0)).xyz;
      minimum = min(minimum, world_corner);
      maximum = max(maximum, world_corner);
      point_count = point_count + 1u;
    }
  }
  if (point_count == 0u) {
    minimum = VKF_DIRECT_SHADOW_BOUNDS_MIN;
    maximum = VKF_DIRECT_SHADOW_BOUNDS_MAX;
  }
  return VkfDirectShadowBounds(minimum, maximum);
}

fn vkf_direct_shadow_bounds_corner(
  bounds: VkfDirectShadowBounds,
  index: u32,
) -> vec3<f32> {
  return vec3<f32>(
    select(bounds.minimum.x, bounds.maximum.x, (index & 1u) != 0u),
    select(bounds.minimum.y, bounds.maximum.y, (index & 2u) != 0u),
    select(bounds.minimum.z, bounds.maximum.z, (index & 4u) != 0u)
  );
}

fn vkf_cube_shadow_direction(face: u32) -> vec3<f32> {
  switch face {
    case 0u: { return vec3<f32>(1.0, 0.0, 0.0); }
    case 1u: { return vec3<f32>(-1.0, 0.0, 0.0); }
    case 2u: { return vec3<f32>(0.0, 1.0, 0.0); }
    case 3u: { return vec3<f32>(0.0, -1.0, 0.0); }
    case 4u: { return vec3<f32>(0.0, 0.0, 1.0); }
    default: { return vec3<f32>(0.0, 0.0, -1.0); }
  }
}

fn vkf_cube_shadow_up(face: u32) -> vec3<f32> {
  return select(
    vec3<f32>(0.0, 0.0, 1.0),
    vec3<f32>(0.0, 1.0, 0.0),
    face >= 4u
  );
}

fn vkf_cube_shadow_view_projection(
  light: SceneLight,
  face: u32,
  near_plane: f32,
  far_plane: f32,
) -> mat4x4<f32> {
  let eye = light.position_and_range.xyz;
  return vkf_perspective(
    1.5707963267948966, 1.0, near_plane, far_plane) *
    vkf_look_at(
      eye,
      eye + vkf_cube_shadow_direction(face),
      vkf_cube_shadow_up(face)
    );
}

fn vkf_cube_shadow_face(direction: vec3<f32>) -> u32 {
  let absolute = abs(direction);
  if (absolute.x >= absolute.y && absolute.x >= absolute.z) {
    return select(1u, 0u, direction.x >= 0.0);
  }
  if (absolute.y >= absolute.z) {
    return select(3u, 2u, direction.y >= 0.0);
  }
  return select(5u, 4u, direction.z >= 0.0);
}

fn vkf_direct_shadow_view(
  light: SceneLight,
  bounds: VkfDirectShadowBounds,
) -> mat4x4<f32> {
  let center = (bounds.minimum + bounds.maximum) * 0.5;
  let direction = vkf_safe_normalize(center - light.position_and_range.xyz);
  let up = vkf_adaptive_shadow_up(direction);
  return vkf_look_at(light.position_and_range.xyz, center, up);
}

fn vkf_direct_shadow_near_far(
  light: SceneLight,
  view: mat4x4<f32>,
  bounds: VkfDirectShadowBounds,
) -> vec2<f32> {
  var min_depth = 1.0e30;
  var max_depth = 0.0;
  for (var index = 0u; index < 8u; index = index + 1u) {
    let camera_corner = view * vec4<f32>(
      vkf_direct_shadow_bounds_corner(bounds, index), 1.0);
    let depth = max(-camera_corner.z, 1.0e-4);
    min_depth = min(min_depth, depth);
    max_depth = max(max_depth, depth);
  }
  let source_near = max(0.01, light.target_and_radius.w * 0.05);
  let near_plane = max(source_near, min_depth * 0.5);
  let far_plane = max(
    max(near_plane + 0.01, light.position_and_range.w),
    max_depth * 1.05
  );
  return vec2<f32>(near_plane, far_plane);
}

fn vkf_fit_direct_shadow_view_projection(
  light: SceneLight,
  near_plane: f32,
  far_plane: f32,
  bounds: VkfDirectShadowBounds,
) -> mat4x4<f32> {
  let view = vkf_direct_shadow_view(light, bounds);
  var min_x = 1.0e30;
  var max_x = -1.0e30;
  var min_y = 1.0e30;
  var max_y = -1.0e30;
  for (var index = 0u; index < 8u; index = index + 1u) {
    let camera_corner = view * vec4<f32>(
      vkf_direct_shadow_bounds_corner(bounds, index), 1.0);
    let scale = near_plane / max(-camera_corner.z, 1.0e-4);
    min_x = min(min_x, camera_corner.x * scale);
    max_x = max(max_x, camera_corner.x * scale);
    min_y = min(min_y, camera_corner.y * scale);
    max_y = max(max_y, camera_corner.y * scale);
  }
  let center_x = (min_x + max_x) * 0.5;
  let center_y = (min_y + max_y) * 0.5;
  let half_width = max((max_x - min_x) * 0.515, 1.0e-5);
  let half_height = max((max_y - min_y) * 0.515, 1.0e-5);
  let left = center_x - half_width;
  let right = center_x + half_width;
  let bottom = center_y - half_height;
  let top = center_y + half_height;
  let width = right - left;
  let height = top - bottom;
  let depth = far_plane / (near_plane - far_plane);
  let projection = mat4x4<f32>(
    vec4<f32>(2.0 * near_plane / width, 0.0, 0.0, 0.0),
    vec4<f32>(0.0, 2.0 * near_plane / height, 0.0, 0.0),
    vec4<f32>((right + left) / width,
      (top + bottom) / height, depth, -1.0),
    vec4<f32>(0.0, 0.0, near_plane * depth, 0.0)
  );
  return projection * view;
}


fn vkf_store_shadow_matrix(
  light_index: u32,
  bounds: VkfDirectShadowBounds,
) {
  let shadow_slot = vkf_shadow_slot(light_index);
  if (shadow_slot >= 0) {
    let shadow_view_count = vkf_shadow_view_count(light_index);
    derived_lights[light_index].kind_and_shadow.z = f32(shadow_slot);
    derived_lights[light_index].kind_and_shadow.w = f32(shadow_view_count);
    if (shadow_view_count == 6u) {
      let near_plane = max(
        0.01, derived_lights[light_index].target_and_radius.w * 0.05);
      let far_plane = max(
        near_plane + 0.01,
        derived_lights[light_index].position_and_range.w);
      for (var face = 0u; face < 6u; face = face + 1u) {
        let view_index = u32(shadow_slot) + face;
        derived_scene.shadow_near_far[view_index] =
          vec4<f32>(near_plane, far_plane, 0.0, 0.0);
        derived_scene.light_view_projection[view_index] =
          vkf_cube_shadow_view_projection(
            derived_lights[light_index], face, near_plane, far_plane);
      }
      return;
    }
    let view = vkf_direct_shadow_view(derived_lights[light_index], bounds);
    let near_far = vkf_direct_shadow_near_far(
      derived_lights[light_index], view, bounds);
    let near_plane = near_far.x;
    let far_plane = near_far.y;
    derived_scene.shadow_near_far[u32(shadow_slot)] =
      vec4<f32>(near_plane, far_plane, 0.0, 0.0);
    derived_scene.light_view_projection[u32(shadow_slot)] =
      vkf_fit_direct_shadow_view_projection(
        derived_lights[light_index], near_plane, far_plane, bounds);
  }
}

@compute @workgroup_size(64)
fn vkf_prepare_frame(@builtin(global_invocation_id) invocation: vec3<u32>) {
  let item_index = invocation.x;
  if (item_index == 0u) {
    let eye = vec3<f32>(raw_camera[0], raw_camera[1], raw_camera[2]);
    let focus_point = vec3<f32>(raw_camera[3], raw_camera[4], raw_camera[5]);
    let up = vec3<f32>(raw_camera[6], raw_camera[7], raw_camera[8]);
    let near_plane = max(raw_camera[10], 1.0e-4);
    let far_plane = max(raw_camera[11], near_plane + 0.01);
    let aspect = viewport.width / max(viewport.height, 1.0);
    derived_scene.view_projection = vkf_perspective(
      raw_camera[9] * 0.017453292519943295,
      aspect,
      near_plane,
      far_plane
    ) * vkf_look_at(eye, focus_point, up);
    derived_scene.view_position = vec4<f32>(eye, 1.0);
    derived_scene.ambient = vec4<f32>(
      raw_camera[12], raw_camera[13], raw_camera[14], raw_camera[15]);
  }
  if (item_index < VKF_LIGHT_COUNT) {
    let base = item_index * 28u;
    derived_lights[item_index].position_and_range = vec4<f32>(
      raw_lights[base], raw_lights[base + 1u], raw_lights[base + 2u],
      max(raw_lights[base + 11u], 0.0));
    derived_lights[item_index].color_and_intensity = vec4<f32>(
      raw_lights[base + 6u], raw_lights[base + 7u], raw_lights[base + 8u],
      raw_lights[base + 10u]);
    derived_lights[item_index].target_and_radius = vec4<f32>(
      raw_lights[base + 3u], raw_lights[base + 4u], raw_lights[base + 5u],
      raw_lights[base + 12u]);
    derived_lights[item_index].kind_and_shadow = vec4<f32>(
      raw_lights[base + 13u], raw_lights[base + 14u], -1.0, -1.0);
    derived_lights[item_index].aperture_float_offset = 0u;
    derived_lights[item_index].aperture_vertex_count = 0u;
    derived_lights[item_index].aperture_vertex_stride_floats = 0u;
    derived_lights[item_index].aperture_object_index = 0u;
    derived_lights[item_index].polarization = vec4<f32>(
      raw_lights[base + 20u], raw_lights[base + 21u],
      raw_lights[base + 22u], raw_lights[base + 23u]);
    derived_lights[item_index].polarization_basis = vec4<f32>(
      raw_lights[base + 24u], raw_lights[base + 25u],
      raw_lights[base + 26u], raw_lights[base + 27u]);
  }
  if (item_index < VKF_OBJECT_COUNT) {
    let base = item_index * 32u;
    let center = vec3<f32>(
      raw_objects[base], raw_objects[base + 1u], raw_objects[base + 2u]);
    let scale = vec3<f32>(
      raw_objects[base + 3u], raw_objects[base + 4u],
      raw_objects[base + 5u]);
    let rotation = vkf_rotation_matrix(vec3<f32>(
      raw_objects[base + 6u], raw_objects[base + 7u],
      raw_objects[base + 8u]));
    derived_objects_write[item_index].value.model =
      vkf_translation_matrix(center) * rotation * vkf_scale_matrix(scale);
    derived_objects_write[item_index].value.normal_matrix = rotation *
      vkf_scale_matrix(vec3<f32>(1.0) /
        max(abs(scale), vec3<f32>(1.0e-6)));
    derived_objects_write[item_index].value.base_color = vec4<f32>(
      raw_objects[base + 9u], raw_objects[base + 10u],
      raw_objects[base + 11u], raw_objects[base + 12u]);
    derived_objects_write[item_index].value.checker_color_a = vec4<f32>(
      raw_objects[base + 13u], raw_objects[base + 14u],
      raw_objects[base + 15u], raw_objects[base + 16u]);
    derived_objects_write[item_index].value.checker_color_b = vec4<f32>(
      raw_objects[base + 17u], raw_objects[base + 18u],
      raw_objects[base + 19u], raw_objects[base + 20u]);
    derived_objects_write[item_index].value.checker_scale = vec2<f32>(
      raw_objects[base + 21u], raw_objects[base + 22u]);
    derived_objects_write[item_index].value.reflectivity = raw_objects[base + 23u];
    derived_objects_write[item_index].value.receives_shadow =
      u32(raw_objects[base + 24u]);
    derived_objects_write[item_index].value.texture_kind =
      u32(raw_objects[base + 25u]);
    derived_objects_write[item_index].value.reflection_depth = 0u;
    derived_objects_write[item_index].value.roughness =
      clamp(raw_objects[base + 26u], 0.02, 1.0);
    derived_objects_write[item_index].value.specular_strength =
      max(raw_objects[base + 27u], 0.0);
    derived_objects_write[item_index].value.no_backface_specular =
      u32(raw_objects[base + 28u]);
    derived_objects_write[item_index].value.surface_kind =
      u32(raw_objects[base + 29u]);
    derived_objects_write[item_index].value.reflection_camera_index =
      vkf_reflection_camera_slot(item_index);
    derived_objects_write[item_index].value.object_index = item_index;
    derived_objects_write[item_index].value.ior = raw_objects[base + 30u];
    derived_objects_write[item_index].value.extinction = raw_objects[base + 31u];
  }
}

@compute @workgroup_size(1)
fn vkf_refit_shadow_views() {
  // The revision is deliberately evaluated before the refit. The first
  // correctness slice refits every frame; a later cache may skip equal values.
  let transform_revision = vkf_scene_transform_revision();
  let current_bounds = vkf_refit_direct_shadow_bounds();
  if (transform_revision == 0xffffffffu && VKF_OBJECT_COUNT == 0u) {
    return;
  }
  for (var light_index = 0u; light_index < VKF_LIGHT_COUNT;
       light_index = light_index + 1u) {
    if (u32(raw_lights[light_index * 28u + 13u]) != 2u) {
      vkf_store_shadow_matrix(light_index, current_bounds);
    }
  }
}

@compute @workgroup_size(1)
fn vkf_prepare_reflection_camera() {
  if (pass_state.aperture_vertex_count < 3u) {
    return;
  }
  let aperture_0 = vkf_aperture_position(0u);
  var aperture_center = vec3<f32>(0.0);
  for (var vertex_index = 0u;
       vertex_index < pass_state.aperture_vertex_count;
       vertex_index = vertex_index + 1u) {
    aperture_center = aperture_center + vkf_aperture_position(vertex_index);
  }
  aperture_center = aperture_center / f32(pass_state.aperture_vertex_count);
  var strongest_plane_normal = vec3<f32>(0.0);
  for (var triangle_index = 1u;
       triangle_index + 1u < pass_state.aperture_vertex_count;
       triangle_index = triangle_index + 1u) {
    let candidate_plane_normal = cross(
      vkf_aperture_position(triangle_index) - aperture_0,
      vkf_aperture_position(triangle_index + 1u) - aperture_0
    );
    if (dot(candidate_plane_normal, candidate_plane_normal) >
        dot(strongest_plane_normal, strongest_plane_normal)) {
      strongest_plane_normal = candidate_plane_normal;
    }
  }
  let plane_normal = vkf_safe_normalize(strongest_plane_normal);
  let parent_camera_index = vkf_reflection_parent_slot(
    pass_state.camera_state_index);
  var eye = vec3<f32>(raw_camera[0], raw_camera[1], raw_camera[2]);
  var focus_point = vec3<f32>(raw_camera[3], raw_camera[4], raw_camera[5]);
  if (parent_camera_index != 0xffffffffu) {
    eye = derived_scene.mirror_view_position[parent_camera_index].xyz;
    focus_point = derived_scene.mirror_view_target[parent_camera_index].xyz;
  }
  let reflected_eye = vkf_reflect_point(eye, aperture_0, plane_normal);
  let reflected_target = vkf_reflect_point(
    focus_point, aperture_0, plane_normal);
  let reflected_view = vkf_look_at(
    reflected_eye,
    reflected_target,
    vec3<f32>(raw_camera[6], raw_camera[7], raw_camera[8])
  );
  derived_scene.mirror_view_projection[pass_state.camera_state_index] =
    vkf_off_axis_projection(
      reflected_view,
      max(raw_camera[10], 1.0e-4),
      max(raw_camera[11], raw_camera[10] + 0.01)
    ) * reflected_view;
  derived_scene.mirror_view_position[pass_state.camera_state_index] =
    vec4<f32>(reflected_eye, 1.0);
  derived_scene.mirror_view_target[pass_state.camera_state_index] =
    vec4<f32>(reflected_target, 1.0);

  for (var light_index = 0u;
       light_index < VKF_LIGHT_COUNT;
       light_index = light_index + 1u) {
    let base = light_index * 28u;
    let reflect_light_index = i32(raw_lights[base + 15u]);
    let reflect_object_index = i32(raw_lights[base + 16u]);
    if (u32(raw_lights[base + 13u]) == 2u &&
        reflect_light_index >= 0 &&
        reflect_object_index == i32(pass_state.object_index)) {
      let source = derived_lights[u32(reflect_light_index)];
      derived_lights[light_index].color_and_intensity =
        source.color_and_intensity;
      let reflected_light_position = vkf_reflect_point(
        source.position_and_range.xyz, aperture_0, plane_normal);
      let incident_propagation = vkf_safe_normalize(
        aperture_center - source.position_and_range.xyz);
      let incidence_s_axis = vkf_safe_normalize(
        cross(incident_propagation, plane_normal));
      let local_stokes = vkf_rotate_stokes_basis(
        source.polarization,
        incident_propagation,
        source.polarization_basis.xyz,
        incidence_s_axis
      );
      let mirror_material =
        derived_objects[pass_state.object_index].value;
      let reflected_roughness = clamp(mirror_material.roughness, 0.0, 1.0);
      let reflected_coherence = (1.0 - reflected_roughness) *
        (1.0 - reflected_roughness);
      let reflected_stokes = vkf_reflect_stokes(
        abs(dot(incident_propagation, plane_normal)),
        mirror_material.ior,
        mirror_material.reflectivity,
        local_stokes
      );
      let reflected_power = reflected_stokes.x /
        max(local_stokes.x, 1.0e-12);
      derived_lights[light_index].color_and_intensity.w =
        source.color_and_intensity.w * reflected_power * reflected_coherence;
      derived_lights[light_index].polarization = reflected_stokes /
        max(reflected_stokes.x, 1.0e-12);
      let outgoing_propagation = vkf_safe_normalize(
        aperture_center - reflected_light_position);
      derived_lights[light_index].polarization_basis = vec4<f32>(
        vkf_polarization_axis(outgoing_propagation, incidence_s_axis), 0.0);
      derived_lights[light_index].position_and_range = vec4<f32>(
        reflected_light_position,
        source.position_and_range.w
      );
      let reflected_radius = source.target_and_radius.w +
        reflected_roughness * length(
          aperture_center - source.position_and_range.xyz);
      derived_lights[light_index].target_and_radius = vec4<f32>(
        aperture_center,
        reflected_radius
      );
      derived_lights[light_index].aperture_float_offset =
        pass_state.aperture_float_offset;
      derived_lights[light_index].aperture_vertex_count =
        pass_state.aperture_vertex_count;
      derived_lights[light_index].aperture_vertex_stride_floats =
        pass_state.aperture_vertex_stride_floats;
      derived_lights[light_index].aperture_object_index =
        pass_state.object_index;
      let projected_shadow_slot = vkf_shadow_slot(light_index);
      if (projected_shadow_slot >= 0) {
        derived_lights[light_index].kind_and_shadow.z =
          f32(projected_shadow_slot);
        derived_lights[light_index].kind_and_shadow.w =
          1.0;
        let projected_direction =
          derived_lights[light_index].target_and_radius.xyz -
          derived_lights[light_index].position_and_range.xyz;
        let projected_up = vkf_adaptive_shadow_up(projected_direction);
        let projected_view = vkf_look_at(
          derived_lights[light_index].position_and_range.xyz,
          derived_lights[light_index].target_and_radius.xyz,
          vkf_adaptive_shadow_up(projected_direction)
        );
        let projected_forward = vkf_safe_normalize(
          derived_lights[light_index].position_and_range.xyz -
          derived_lights[light_index].target_and_radius.xyz
        );
        let projected_right = vkf_safe_normalize(cross(
          projected_up, projected_forward));
        let aperture_right = vkf_safe_normalize(
          vkf_aperture_position(1u) - aperture_0);
        let projected_near_plane = vkf_aperture_near_plane(
          projected_view,
          max(source.target_and_radius.w * 0.05, 1.0e-4));
        let projected_far_plane = max(
          derived_lights[light_index].position_and_range.w,
          projected_near_plane + 0.01);
        var projected_projection = vkf_off_axis_projection(
          projected_view, projected_near_plane, projected_far_plane);
        if (dot(projected_right, aperture_right) < 0.0) {
          projected_projection = vkf_flip_clip_x() * projected_projection;
        }
        derived_scene.light_view_projection[u32(projected_shadow_slot)] =
          projected_projection * projected_view;
        derived_scene.shadow_near_far[u32(projected_shadow_slot)] =
          vec4<f32>(
            projected_near_plane, projected_far_plane, 0.0, 0.0);
      }
    }
  }
}

struct SceneVertexOut {
  @builtin(position) clip_position: vec4<f32>,
  @location(0) world_position: vec3<f32>,
  @location(1) world_normal: vec3<f32>,
  @location(2) color: vec4<f32>,
  @location(3) local_position: vec3<f32>,
  @location(4) view_position: vec3<f32>,
  @interpolate(flat) @location(5) reflection_camera_index: u32,
  @location(6) local_normal: vec3<f32>,
};

@vertex
fn vkf_scene_vertex(
  @location(0) position: vec3<f32>,
  @location(1) normal: vec3<f32>,
  @location(2) color: vec4<f32>,
) -> SceneVertexOut {
  var out: SceneVertexOut;
  let world_position = object.model * vec4<f32>(position, 1.0);
  out.clip_position = scene.view_projection * world_position;
  out.world_position = world_position.xyz;
  out.world_normal = normalize((object.normal_matrix * vec4<f32>(normal, 0.0)).xyz);
  out.color = color * object.base_color;
  out.local_position = position;
  out.local_normal = normal;
  out.view_position = scene.view_position.xyz;
  out.reflection_camera_index = object.reflection_camera_index;
  return out;
}

@vertex
fn vkf_reflection_vertex(
  @location(0) position: vec3<f32>,
  @location(1) normal: vec3<f32>,
  @location(2) color: vec4<f32>,
) -> SceneVertexOut {
  var out: SceneVertexOut;
  let world_position = object.model * vec4<f32>(position, 1.0);
  out.clip_position = scene.mirror_view_projection[
    pass_state.camera_state_index] * world_position;
  out.world_position = world_position.xyz;
  out.world_normal = normalize((object.normal_matrix *
    vec4<f32>(normal, 0.0)).xyz);
  out.color = color * object.base_color;
  out.local_position = position;
  out.local_normal = normal;
  out.view_position = scene.mirror_view_position[
    pass_state.camera_state_index].xyz;
  out.reflection_camera_index = vkf_next_reflection_camera_slot(
    pass_state.camera_state_index, object.object_index);
  return out;
}

@vertex
fn vkf_shadow_vertex(
  @location(0) position: vec3<f32>,
) -> @builtin(position) vec4<f32> {
  return scene.light_view_projection[pass_state.camera_state_index] *
    object.model * vec4<f32>(position, 1.0);
}

fn vkf_checker_color(
  local_position: vec3<f32>,
  local_normal: vec3<f32>,
) -> vec4<f32> {
  let normal_weight = abs(local_normal);
  var planar_position = local_position.xy;
  if (normal_weight.y >= normal_weight.x &&
      normal_weight.y >= normal_weight.z) {
    planar_position = local_position.xz;
  } else if (normal_weight.x >= normal_weight.z) {
    planar_position = local_position.yz;
  }
  let checker_position = planar_position * object.checker_scale;
  let pixel_span = max(fwidth(checker_position), vec2<f32>(1.0e-3));
  let lower_integral = abs(
    fract((checker_position - 0.5 * pixel_span) * 0.5) - vec2<f32>(0.5));
  let upper_integral = abs(
    fract((checker_position + 0.5 * pixel_span) * 0.5) - vec2<f32>(0.5));
  let axis_average = 2.0 * (lower_integral - upper_integral) / pixel_span;
  let checker_coverage = clamp(
    0.5 - 0.5 * axis_average.x * axis_average.y, 0.0, 1.0);
  return mix(object.checker_color_a, object.checker_color_b, checker_coverage);
}

const VKF_SHADOW_BLOCKER_SAMPLE_COUNT: u32 = 16u;
const VKF_SHADOW_FILTER_SAMPLE_COUNT: u32 = 32u;
const VKF_SHADOW_DISK: array<vec2<f32>, 32> = array<vec2<f32>, 32>(
  vec2<f32>(0.125000, 0.000000),
  vec2<f32>(-0.159645, 0.146248),
  vec2<f32>(0.024436, -0.278438),
  vec2<f32>(0.201222, 0.262459),
  vec2<f32>(-0.369268, -0.065318),
  vec2<f32>(0.349802, -0.222516),
  vec2<f32>(-0.117002, 0.435242),
  vec2<f32>(-0.223136, -0.429634),
  vec2<f32>(0.484115, 0.176798),
  vec2<f32>(-0.503641, 0.207896),
  vec2<f32>(0.242788, -0.518824),
  vec2<f32>(0.179414, 0.572001),
  vec2<f32>(-0.540757, -0.313380),
  vec2<f32>(0.634370, -0.139464),
  vec2<f32>(-0.387146, 0.550675),
  vec2<f32>(-0.089440, -0.690200),
  vec2<f32>(0.549072, 0.462758),
  vec2<f32>(-0.738878, 0.030555),
  vec2<f32>(0.538955, -0.536332),
  vec2<f32>(-0.036058, 0.779792),
  vec2<f32>(-0.512818, -0.614527),
  vec2<f32>(0.812360, 0.109302),
  vec2<f32>(-0.688311, 0.478909),
  vec2<f32>(0.188086, -0.836061),
  vec2<f32>(0.435033, 0.759191),
  vec2<f32>(-0.850448, -0.271316),
  vec2<f32>(0.826102, -0.381680),
  vec2<f32>(-0.357888, 0.855156),
  vec2<f32>(-0.319407, -0.888034),
  vec2<f32>(0.849909, 0.446688),
  vec2<f32>(-0.944035, 0.248845),
  vec2<f32>(0.536596, -0.834530)
);

fn vkf_shadow_linear_distance(
  depth: f32,
  near_far: vec2<f32>,
) -> f32 {
  let near_plane = near_far.x;
  let far_plane = near_far.y;
  return near_plane * far_plane /
    max(far_plane - depth * (far_plane - near_plane), 1.0e-6);
}

fn vkf_shadow_projected_source_radius_uv(
  light_view_projection: mat4x4<f32>,
  source_center_world: vec3<f32>,
  source_basis_x_world: vec3<f32>,
  source_basis_y_world: vec3<f32>,
) -> f32 {
  let source_center_clip = light_view_projection *
    vec4<f32>(source_center_world, 1.0);
  let source_basis_x_clip = light_view_projection *
    vec4<f32>(source_basis_x_world, 1.0);
  let source_basis_y_clip = light_view_projection *
    vec4<f32>(source_basis_y_world, 1.0);
  if (source_center_clip.w <= 1.0e-6 ||
      source_basis_x_clip.w <= 1.0e-6 ||
      source_basis_y_clip.w <= 1.0e-6) {
    return 0.0;
  }
  let source_center_uv = source_center_clip.xy /
    source_center_clip.w * vec2<f32>(0.5, -0.5);
  let source_basis_x_uv = source_basis_x_clip.xy /
    source_basis_x_clip.w * vec2<f32>(0.5, -0.5);
  let source_basis_y_uv = source_basis_y_clip.xy /
    source_basis_y_clip.w * vec2<f32>(0.5, -0.5);
  return max(
    length(source_basis_x_uv - source_center_uv),
    length(source_basis_y_uv - source_center_uv));
}

fn vkf_shadow_receiver_bias(
  world_position: vec3<f32>,
  surface_normal: vec3<f32>,
  light_direction: vec3<f32>,
  light_view_projection: mat4x4<f32>,
  texel_size: vec2<f32>,
) -> f32 {
  let unit_light_direction = vkf_safe_normalize(light_direction);
  let basis_hint = select(
    vec3<f32>(0.0, 0.0, 1.0),
    vec3<f32>(0.0, 1.0, 0.0),
    abs(unit_light_direction.z) > 0.9);
  let basis_x = vkf_safe_normalize(cross(
    basis_hint, unit_light_direction));
  let basis_y = cross(unit_light_direction, basis_x);
  let projected_world_radius_uv = vkf_shadow_projected_source_radius_uv(
    light_view_projection,
    world_position,
    world_position + basis_x,
    world_position + basis_y);
  let texel_radius = max(texel_size.x, texel_size.y);
  let world_per_texel = texel_radius /
    max(projected_world_radius_uv, 1.0e-6);
  let slope = 1.0 - clamp(dot(
    vkf_safe_normalize(surface_normal), unit_light_direction), 0.0, 1.0);
  let world_bias = max(0.75, 3.0 * slope) * world_per_texel;
  let receiver_clip = light_view_projection *
    vec4<f32>(world_position, 1.0);
  let biased_clip = light_view_projection * vec4<f32>(
    world_position + unit_light_direction * world_bias, 1.0);
  let receiver_depth = receiver_clip.z / receiver_clip.w;
  let biased_depth = biased_clip.z / biased_clip.w;
  return max(receiver_depth - biased_depth, 0.0);
}

fn vkf_shadow_visibility(
  world_position: vec3<f32>,
  surface_normal: vec3<f32>,
  light: SceneLight,
) -> f32 {
  if (object.receives_shadow == 0u) {
    return 1.0;
  }
  let shadow_base = u32(light.kind_and_shadow.z);
  let shadow_view_count = u32(light.kind_and_shadow.w);
  var shadow_camera_index = shadow_base;
  var shadow_layer = i32(shadow_base);
  if (shadow_view_count == 6u) {
    let face = vkf_cube_shadow_face(
      world_position - light.position_and_range.xyz);
    shadow_camera_index = shadow_base + face;
    shadow_layer = i32(shadow_camera_index);
  }
  let light_view_projection =
    scene.light_view_projection[shadow_camera_index];
  let light_clip = light_view_projection * vec4<f32>(world_position, 1.0);
  let light_ndc = light_clip.xyz / light_clip.w;
  if (light_clip.w <= 0.0 ||
      light_ndc.x < -1.0 || light_ndc.x > 1.0 ||
      light_ndc.y < -1.0 || light_ndc.y > 1.0 ||
      light_ndc.z < 0.0 || light_ndc.z > 1.0) {
    return 1.0;
  }
  let uv = vec2<f32>(light_ndc.x * 0.5 + 0.5, 0.5 - light_ndc.y * 0.5);
  let depth = light_ndc.z;
  let shadow_dimensions = textureDimensions(shadow_depth, 0);
  let shadow_size = vec2<f32>(shadow_dimensions);
  let texel_size = 1.0 / shadow_size;
  let light_direction = vkf_safe_normalize(
    light.position_and_range.xyz - world_position);
  let compare_depth = depth - vkf_shadow_receiver_bias(
    world_position,
    surface_normal,
    light_direction,
    light_view_projection,
    texel_size);
  let near_far = scene.shadow_near_far[shadow_camera_index].xy;
  let receiver_view_distance = vkf_shadow_linear_distance(depth, near_far);
  let receiver_distance = length(
    world_position - light.position_and_range.xyz);
  let blocker_ray_scale = receiver_distance /
    max(receiver_view_distance, 1.0e-4);
  let source_radius = max(light.target_and_radius.w, 0.0);
  if (source_radius <= 1.0e-6) {
    return textureSampleCompareLevel(
      shadow_depth, shadow_sampler, uv, shadow_layer, compare_depth);
  }
  let source_direction = vkf_safe_normalize(
    world_position - light.position_and_range.xyz);
  let source_basis_hint = select(
    vec3<f32>(0.0, 0.0, 1.0),
    vec3<f32>(0.0, 1.0, 0.0),
    abs(source_direction.z) > 0.9);
  let source_axis_x = vkf_safe_normalize(cross(
    source_basis_hint, source_direction));
  let source_axis_y = cross(source_direction, source_axis_x);
  let source_center_world = world_position;
  let source_basis_x_world = source_center_world +
    source_axis_x * source_radius;
  let source_basis_y_world = source_center_world +
    source_axis_y * source_radius;
  let source_radius_uv = vkf_shadow_projected_source_radius_uv(
    light_view_projection,
    source_center_world,
    source_basis_x_world,
    source_basis_y_world);
  let texel_radius = max(texel_size.x, texel_size.y);
  let search_radius_uv = clamp(
    source_radius_uv,
    4.0 * texel_radius, 24.0 * texel_radius);
  let uv_min = texel_size * 0.5;
  let uv_max = vec2<f32>(1.0) - uv_min;
  var blocker_distance_sum = 0.0;
  var blocker_count = 0.0;
  for (var sample_index = 0u;
       sample_index < VKF_SHADOW_BLOCKER_SAMPLE_COUNT;
       sample_index = sample_index + 1u) {
    let sample_offset = VKF_SHADOW_DISK[sample_index * 2u];
    let sample_uv = clamp(
      uv + sample_offset * search_radius_uv, uv_min, uv_max);
    let sample_texel = vec2<i32>(sample_uv * shadow_size);
    let sample_depth = textureLoad(
      shadow_depth, sample_texel, shadow_layer, 0);
    if (sample_depth < compare_depth) {
      blocker_distance_sum = blocker_distance_sum +
        vkf_shadow_linear_distance(sample_depth, near_far) *
        blocker_ray_scale;
      blocker_count = blocker_count + 1.0;
    }
  }
  if (blocker_count < 0.5) {
    return 1.0;
  }
  let average_blocker_distance = blocker_distance_sum / blocker_count;
  let penumbra_ratio = max(
    receiver_distance - average_blocker_distance, 0.0) /
    max(average_blocker_distance, 1.0e-4);
  let filter_radius_uv = clamp(
    source_radius_uv * penumbra_ratio,
    3.0 * texel_radius, 32.0 * texel_radius);
  var visibility = 0.0;
  for (var sample_index = 0u;
       sample_index < VKF_SHADOW_FILTER_SAMPLE_COUNT;
       sample_index = sample_index + 1u) {
    let sample_offset = VKF_SHADOW_DISK[sample_index];
    let sample_uv = clamp(
      uv + sample_offset * filter_radius_uv, uv_min, uv_max);
    visibility = visibility + textureSampleCompareLevel(
      shadow_depth, shadow_sampler, sample_uv, shadow_layer, compare_depth);
  }
  return visibility / f32(VKF_SHADOW_FILTER_SAMPLE_COUNT);
}

fn vkf_light_aperture_position(
  light: SceneLight,
  vertex_index: u32,
) -> vec3<f32> {
  let base = light.aperture_float_offset +
    vertex_index * light.aperture_vertex_stride_floats;
  let local_position = vec3<f32>(
    aperture_vertices[base],
    aperture_vertices[base + 1u],
    aperture_vertices[base + 2u]
  );
  let model = derived_objects[light.aperture_object_index].value.model;
  return (model * vec4<f32>(local_position, 1.0)).xyz;
}

fn vkf_planar_aperture_coverage(
  world_position: vec3<f32>,
  source_position: vec3<f32>,
  aperture_light: SceneLight,
) -> f32 {
  if (aperture_light.aperture_vertex_count < 3u) {
    return 0.0;
  }
  let aperture_0 = vkf_light_aperture_position(aperture_light, 0u);
  let aperture_1 = vkf_light_aperture_position(aperture_light, 1u);
  let aperture_2 = vkf_light_aperture_position(aperture_light, 2u);
  let plane_normal = vkf_safe_normalize(cross(
    aperture_1 - aperture_0, aperture_2 - aperture_0));
  let light_side = dot(source_position - aperture_0, plane_normal);
  let point_side = dot(world_position - aperture_0, plane_normal);
  let receiver_gap = -sign(light_side) * point_side;
  if (receiver_gap < -1.0e-5) {
    return 0.0;
  }
  let ray = world_position - source_position;
  let denominator = dot(plane_normal, ray);
  if (abs(denominator) <= 1.0e-6) {
    return 0.0;
  }
  let hit_distance = dot(
    plane_normal, aperture_0 - source_position) / denominator;
  if (hit_distance <= 1.0e-5 || hit_distance > 1.0 + 1.0e-5) {
    return 0.0;
  }
  let hit = source_position + ray * hit_distance;
  let light_to_plane = max(abs(light_side), 1.0e-4);
  let softness = max(aperture_light.target_and_radius.w, 0.0) *
    max(receiver_gap, 0.0) / light_to_plane;
  let edge_softness = max(softness, 1.0e-5);
  var positive_coverage = 1.0;
  var negative_coverage = 1.0;
  for (var vertex_index = 0u;
       vertex_index < aperture_light.aperture_vertex_count;
       vertex_index = vertex_index + 1u) {
    let next_index = (vertex_index + 1u) %
      aperture_light.aperture_vertex_count;
    let edge_start = vkf_light_aperture_position(
      aperture_light, vertex_index);
    let edge_end = vkf_light_aperture_position(
      aperture_light, next_index);
    let edge = edge_end - edge_start;
    let signed_distance = dot(
      cross(edge, hit - edge_start), plane_normal) /
      max(length(edge), 1.0e-6);
    positive_coverage = positive_coverage * smoothstep(
      -edge_softness, edge_softness, signed_distance);
    negative_coverage = negative_coverage * smoothstep(
      -edge_softness, edge_softness, -signed_distance);
  }
  return max(positive_coverage, negative_coverage);
}

fn vkf_projected_light_aperture(
  world_position: vec3<f32>,
  light: SceneLight,
  receiver_object_index: u32,
) -> f32 {
  if (u32(light.kind_and_shadow.x) != 2u) {
    return 1.0;
  }
  if (receiver_object_index == light.aperture_object_index) {
    return 0.0;
  }
  return vkf_planar_aperture_coverage(
    world_position, light.position_and_range.xyz, light);
}


fn vkf_planar_reflection(
  world_position: vec3<f32>,
  reflection_camera_index: u32,
) -> vec4<f32> {
  if (reflection_camera_index == 0xffffffffu) {
    return VKF_BACKGROUND_RADIANCE;
  }
  let mirror_clip = scene.mirror_view_projection[
    reflection_camera_index] * vec4<f32>(world_position, 1.0);
  if (mirror_clip.w <= 0.0) {
    return VKF_BACKGROUND_RADIANCE;
  }
  let mirror_ndc = mirror_clip.xyz / mirror_clip.w;
  if (mirror_ndc.x < -1.0 || mirror_ndc.x > 1.0 ||
      mirror_ndc.y < -1.0 || mirror_ndc.y > 1.0 ||
      mirror_ndc.z < 0.0 || mirror_ndc.z > 1.0) {
    return VKF_BACKGROUND_RADIANCE;
  }
  let uv = vec2<f32>(mirror_ndc.x * 0.5 + 0.5, 0.5 - mirror_ndc.y * 0.5);
  return textureSampleLevel(
    planar_reflection_texture, planar_reflection_sampler, uv, 0.0);
}

fn vkf_fresnel_amplitudes(
  cos_theta_i: f32,
  ior: f32,
) -> vec2<f32> {
  if (ior <= 0.0) {
    return vec2<f32>(-1.0, 1.0);
  }
  let c_i = clamp(abs(cos_theta_i), 0.0, 1.0);
  let sin_theta_t_squared = (1.0 - c_i * c_i) / (ior * ior);
  if (sin_theta_t_squared >= 1.0) {
    return vec2<f32>(-1.0, 1.0);
  }
  let c_t = sqrt(max(1.0 - sin_theta_t_squared, 0.0));
  let rs_amplitude = (c_i - ior * c_t) / (c_i + ior * c_t);
  let rp_amplitude = (ior * c_i - c_t) / (ior * c_i + c_t);
  return vec2<f32>(rs_amplitude, rp_amplitude);
}

fn vkf_reflect_stokes(
  cos_theta_i: f32,
  ior: f32,
  reflectivity: f32,
  polarization: vec4<f32>,
) -> vec4<f32> {
  var amplitudes = vkf_fresnel_amplitudes(cos_theta_i, ior);
  if (ior <= 0.0) {
    let amplitude = sqrt(clamp(reflectivity, 0.0, 1.0));
    amplitudes = vec2<f32>(-amplitude, amplitude);
  }
  let rs_amplitude = amplitudes.x;
  let rp_amplitude = amplitudes.y;
  let rs = rs_amplitude * rs_amplitude;
  let rp = rp_amplitude * rp_amplitude;
  let sum = rs + rp;
  let difference = rs - rp;
  return vec4<f32>(
    0.5 * (sum * polarization.x + difference * polarization.y),
    0.5 * (difference * polarization.x + sum * polarization.y),
    rs_amplitude * rp_amplitude * polarization.z,
    rs_amplitude * rp_amplitude * polarization.w
  );
}

fn vkf_shade_authored_material(
  input: SceneVertexOut,
  front_facing: bool,
) -> vec4<f32> {
  var material_color = input.color;
  if (object.texture_kind == 1u) {
    material_color = vkf_checker_color(
      input.local_position, input.local_normal);
  }

  if (object.surface_kind == 2u && !front_facing) {
    let ambient_backface = material_color.rgb * scene.ambient.rgb;
    return vec4<f32>(ambient_backface, material_color.a);
  }
  let geometric_normal = normalize(input.world_normal);
  let n = select(-geometric_normal, geometric_normal, front_facing);
  let view_direction = vkf_safe_normalize(
    input.view_position - input.world_position);
  var diffuse_rgb = vec3<f32>(0.0);
  var specular_rgb = vec3<f32>(0.0);
  for (var light_index: u32 = 0u;
       light_index < VKF_LIGHT_COUNT;
       light_index = light_index + 1u) {
    let light = lights[light_index];
    var visibility = vkf_projected_light_aperture(
      input.world_position, light, object.object_index);
    if (visibility <= 0.0) {
      continue;
    }
    let to_light =
      light.position_and_range.xyz - input.world_position;
    let sampled_transport = vkf_sample_light_transport(
      input.world_position, light, to_light);
    let l = sampled_transport.xyz;
    let diffuse = max(dot(n, l), 0.0);
    var specular = 0.0;
    if (object.specular_strength > 1.0e-6) {
      let half_direction = vkf_safe_normalize(l + view_direction);
      let shininess = max(2.0 / pow(object.roughness, 4.0) - 2.0, 1.0);
      specular = pow(max(dot(n, half_direction), 0.0), shininess) *
        object.specular_strength;
      let incidence_s_axis = vkf_safe_normalize(
        cross(-l, half_direction));
      let local_stokes = vkf_rotate_stokes_basis(
        light.polarization,
        -l,
        light.polarization_basis.xyz,
        incidence_s_axis
      );
      let reflected_stokes = vkf_reflect_stokes(
        dot(l, half_direction),
        object.ior,
        object.reflectivity,
        local_stokes
      );
      specular *= reflected_stokes.x / max(local_stokes.x, 1.0e-12);
    }
    if (!front_facing && object.no_backface_specular != 0u) {
      specular = 0.0;
    }
    let attenuation = sampled_transport.w;
    let receiver_light_mask =
      vkf_shadow_receiver_light_mask(object.object_index);
    let receives_light_shadow = light_index < 32u &&
      ((receiver_light_mask >> light_index) & 1u) != 0u;
    if (light.kind_and_shadow.y > 0.5 && receives_light_shadow) {
      visibility = visibility * vkf_shadow_visibility(
        input.world_position, n, light);
    }
    let radiance = light.color_and_intensity.rgb *
      attenuation * visibility;
    diffuse_rgb = diffuse_rgb + radiance * diffuse;
    specular_rgb = specular_rgb + radiance * specular;
  }
  let shaded = material_color.rgb *
    (scene.ambient.rgb + diffuse_rgb) + specular_rgb;
  return vec4<f32>(shaded, material_color.a);
}

@fragment
fn vkf_terminal_scene_fragment(
  input: SceneVertexOut,
  @builtin(front_facing) front_facing: bool,
) -> @location(0) vec4<f32> {
  if (object.reflectivity >= 0.999) {
    return VKF_BACKGROUND_RADIANCE;
  }
  return vkf_shade_authored_material(input, front_facing);
}

@fragment
fn vkf_scene_fragment(
  input: SceneVertexOut,
  @builtin(front_facing) front_facing: bool,
) -> @location(0) vec4<f32> {
  let material = vkf_shade_authored_material(input, front_facing);
  var shaded = material.rgb;
  let mirror_front_visible =
    object.surface_kind != 2u || front_facing;
  if (object.reflectivity > 0.0 && mirror_front_visible &&
      object.reflection_depth <= 2u) {
    let reflected = vkf_planar_reflection(
      input.world_position, input.reflection_camera_index);
    let reflection_coverage = object.reflectivity * reflected.a;
    shaded = mix(shaded, reflected.rgb, reflection_coverage);
  }
  return vec4<f32>(shaded, material.a);
}


struct FlareVertexOut {
  @builtin(position) clip_position: vec4<f32>,
  @location(0) local_position: vec2<f32>,
  @location(1) emitted_radiance: vec3<f32>,
  @location(2) enabled: f32,
  @location(3) source_ratio: f32,
  @location(4) bloom_strength: f32,
  @location(5) compactness: f32,
};

struct EmitterVertexOut {
  @builtin(position) clip_position: vec4<f32>,
  @location(0) emitted_radiance: vec3<f32>,
  @location(1) enabled: f32,
  @location(2) view_facing: f32,
};

const VKF_EMITTER_LATITUDE_SEGMENTS: u32 = 32u;
const VKF_EMITTER_LONGITUDE_SEGMENTS: u32 = 48u;
const VKF_EMITTER_VERTEX_COUNT: u32 =
  VKF_EMITTER_LATITUDE_SEGMENTS * VKF_EMITTER_LONGITUDE_SEGMENTS * 6u;

fn vkf_emitter_sphere_direction(vertex_index: u32) -> vec3<f32> {
  let cell_index = vertex_index / 6u;
  let corner_index = vertex_index % 6u;
  let latitude_index = cell_index / VKF_EMITTER_LONGITUDE_SEGMENTS;
  let longitude_index = cell_index % VKF_EMITTER_LONGITUDE_SEGMENTS;
  let corner_offsets = array<vec2<u32>, 6>(
    vec2<u32>(0u, 0u), vec2<u32>(0u, 1u), vec2<u32>(1u, 0u),
    vec2<u32>(1u, 0u), vec2<u32>(0u, 1u), vec2<u32>(1u, 1u)
  );
  let corner = corner_offsets[corner_index];
  let latitude = f32(latitude_index + corner.x) /
    f32(VKF_EMITTER_LATITUDE_SEGMENTS);
  let longitude = f32(longitude_index + corner.y) /
    f32(VKF_EMITTER_LONGITUDE_SEGMENTS);
  let theta = latitude * 3.141592653589793;
  let phi = longitude * 6.283185307179586;
  return vec3<f32>(
    sin(theta) * cos(phi),
    sin(theta) * sin(phi),
    cos(theta)
  );
}

fn vkf_emitter_geometry_vertex(
  vertex_index: u32,
  light_index: u32,
  viewer_position: vec3<f32>,
  view_projection: mat4x4<f32>,
) -> EmitterVertexOut {
  let base = light_index * 28u;
  let source_position = vec3<f32>(
    raw_lights[base], raw_lights[base + 1u], raw_lights[base + 2u]);
  let source_radius = max(raw_lights[base + 12u], 0.002);
  let authored_radius = select(
    max(source_radius, 0.18), source_radius,
    u32(raw_lights[base + 13u]) == 5u);
  let direction = vkf_emitter_sphere_direction(vertex_index);
  let world_position = source_position + direction * authored_radius;
  let view_direction = vkf_safe_normalize(viewer_position - world_position);
  var out: EmitterVertexOut;
  out.clip_position = view_projection * vec4<f32>(world_position, 1.0);
  var emitted_radiance = vec3<f32>(
    raw_lights[base + 6u], raw_lights[base + 7u], raw_lights[base + 8u]) *
    max(raw_lights[base + 10u], 0.0);
  if (u32(raw_lights[base + 13u]) == 5u) {
    emitted_radiance = emitted_radiance / max(
      3.141592653589793 * authored_radius * authored_radius, 1.0e-8);
  }
  out.emitted_radiance = emitted_radiance;
  let is_physical = select(0.0, 1.0, u32(raw_lights[base + 13u]) != 2u);
  let is_enabled = select(0.0, 1.0, raw_lights[base + 17u] > 0.5);
  out.enabled = is_physical * is_enabled;
  out.view_facing = max(dot(direction, view_direction), 0.0);
  return out;
}

fn vkf_projected_emitter_axes(
  center: vec3<f32>,
  radius: f32,
  viewer_position: vec3<f32>,
  view_projection: mat4x4<f32>,
) -> vec4<f32> {
  let center_clip = view_projection * vec4<f32>(center, 1.0);
  let center_ndc = center_clip.xy / max(abs(center_clip.w), 1.0e-6);
  let view_direction = vkf_safe_normalize(center - viewer_position);
  let reference_up = select(
    vec3<f32>(0.0, 0.0, 1.0),
    vec3<f32>(0.0, 1.0, 0.0),
    abs(view_direction.z) > 0.95
  );
  let tangent_x = vkf_safe_normalize(cross(view_direction, reference_up));
  let tangent_y = vkf_safe_normalize(cross(tangent_x, view_direction));
  let x_clip = view_projection * vec4<f32>(
    center + tangent_x * radius, 1.0);
  let y_clip = view_projection * vec4<f32>(
    center + tangent_y * radius, 1.0);
  let x_axis = x_clip.xy / max(abs(x_clip.w), 1.0e-6) - center_ndc;
  let y_axis = y_clip.xy / max(abs(y_clip.w), 1.0e-6) - center_ndc;
  return vec4<f32>(x_axis, y_axis);
}

fn vkf_flare_frustum_visibility(
  source_clip: vec4<f32>,
  flare_extent_ndc: f32,
) -> f32 {
  let near_visibility = smoothstep(1.0e-3, 5.0e-2, source_clip.w);
  if (near_visibility <= 0.0) {
    return 0.0;
  }
  let source_ndc = source_clip.xy / source_clip.w;
  let viewport_distance = max(abs(source_ndc.x), abs(source_ndc.y)) - 1.0;
  let viewport_visibility = 1.0 - smoothstep(
    0.0, max(flare_extent_ndc, 1.0e-3), viewport_distance);
  return near_visibility * viewport_visibility;
}

fn vkf_flare_billboard_vertex(
  vertex_index: u32,
  light_index: u32,
  viewer_position: vec3<f32>,
  view_projection: mat4x4<f32>,
) -> FlareVertexOut {
  let corners = array<vec2<f32>, 6>(
    vec2<f32>(-1.0, -1.0), vec2<f32>(1.0, -1.0),
    vec2<f32>(-1.0, 1.0), vec2<f32>(-1.0, 1.0),
    vec2<f32>(1.0, -1.0), vec2<f32>(1.0, 1.0)
  );
  let base = light_index * 28u;
  let source_position = vec3<f32>(
    raw_lights[base], raw_lights[base + 1u], raw_lights[base + 2u]);
  let source_clip = view_projection * vec4<f32>(source_position, 1.0);
  let source_ndc = source_clip.xy / max(source_clip.w, 1.0e-3);
  let source_radius = max(raw_lights[base + 12u], 0.002);
  let authored_radius = select(
    max(source_radius, 0.18), source_radius,
    u32(raw_lights[base + 13u]) == 5u);
  var projected_axes = vkf_projected_emitter_axes(
    source_position, authored_radius, viewer_position, view_projection);
  let half_viewport = vec2<f32>(viewport.width, viewport.height) * 0.5;
  let raw_source_radius_px = max(
    length(projected_axes.xy * half_viewport),
    length(projected_axes.zw * half_viewport)
  );
  let source_radius_px = clamp(raw_source_radius_px, 1.0, 96.0);
  projected_axes = projected_axes *
    (source_radius_px / max(raw_source_radius_px, 1.0e-6));
  var emitted_radiance = vec3<f32>(
    raw_lights[base + 6u], raw_lights[base + 7u], raw_lights[base + 8u]) *
    max(raw_lights[base + 10u], 0.0);
  if (u32(raw_lights[base + 13u]) == 5u) {
    emitted_radiance = emitted_radiance / max(
      3.141592653589793 * authored_radius * authored_radius, 1.0e-8);
  }
  let peak_radiance = max(
    emitted_radiance.r, max(emitted_radiance.g, emitted_radiance.b));
  let threshold = 1.0;
  let knee = 0.5;
  var soft = clamp(peak_radiance - threshold + knee, 0.0, 2.0 * knee);
  soft = soft * soft / max(4.0 * knee, 1.0e-6);
  let bright = max(peak_radiance - threshold, soft);
  let bloom_strength = clamp(bright / 32.0, 0.0, 1.0);
  let compactness = clamp(8.0 / (source_radius_px + 8.0), 0.0, 1.0);
  let halo_radius_px = bloom_strength * min(
    4.0, source_radius_px * (0.25 + 0.50 * compactness));
  let flare_radius_px = max(source_radius_px, source_radius_px + halo_radius_px);
  let flare_scale = flare_radius_px / max(source_radius_px, 1.0);
  let flare_extent_ndc = max(
    length(projected_axes.xy), length(projected_axes.zw)) * flare_scale;
  let frustum_visibility = vkf_flare_frustum_visibility(
    source_clip, flare_extent_ndc);
  let corner = corners[vertex_index];
  let clip_xy = source_ndc + (
    corner.x * projected_axes.xy +
    corner.y * projected_axes.zw
  ) * flare_scale;
  var out: FlareVertexOut;
  out.clip_position = select(
    vec4<f32>(2.0, 2.0, 0.0, 1.0),
    vec4<f32>(clip_xy * source_clip.w, source_clip.z, source_clip.w),
    frustum_visibility > 0.0);
  out.local_position = corner;
  out.emitted_radiance = emitted_radiance;
  let is_physical = select(0.0, 1.0, u32(raw_lights[base + 13u]) != 2u);
  let is_enabled = select(0.0, 1.0, raw_lights[base + 17u] > 0.5);
  out.enabled = is_physical * is_enabled * frustum_visibility;
  out.source_ratio = source_radius_px / max(flare_radius_px, 1.0);
  out.bloom_strength = bloom_strength;
  out.compactness = compactness;
  return out;
}

@vertex
fn vkf_emitter_vertex(
  @builtin(vertex_index) vertex_index: u32,
  @builtin(instance_index) light_index: u32,
) -> EmitterVertexOut {
  return vkf_emitter_geometry_vertex(
    vertex_index, light_index, scene.view_position.xyz,
    scene.view_projection);
}

@vertex
fn vkf_reflection_emitter_vertex(
  @builtin(vertex_index) vertex_index: u32,
  @builtin(instance_index) light_index: u32,
) -> EmitterVertexOut {
  return vkf_emitter_geometry_vertex(
    vertex_index, light_index,
    scene.mirror_view_position[pass_state.camera_state_index].xyz,
    scene.mirror_view_projection[pass_state.camera_state_index]);
}

@vertex
fn vkf_flare_vertex(
  @builtin(vertex_index) vertex_index: u32,
  @builtin(instance_index) light_index: u32,
) -> FlareVertexOut {
  return vkf_flare_billboard_vertex(
    vertex_index, light_index, scene.view_position.xyz,
    scene.view_projection);
}

@vertex
fn vkf_reflection_flare_vertex(
  @builtin(vertex_index) vertex_index: u32,
  @builtin(instance_index) light_index: u32,
) -> FlareVertexOut {
  return vkf_flare_billboard_vertex(
    vertex_index,
    light_index,
    scene.mirror_view_position[pass_state.camera_state_index].xyz,
    scene.mirror_view_projection[pass_state.camera_state_index]);
}

@fragment
fn vkf_emitter_fragment(input: EmitterVertexOut) -> @location(0) vec4<f32> {
  if (input.enabled <= 0.0) {
    discard;
  }
  let mapped_radiance = input.emitted_radiance /
    (vec3<f32>(1.0) + input.emitted_radiance);
  let emitter_gradient = smoothstep(0.0, 1.0, input.view_facing);
  return vec4<f32>(
    mapped_radiance * emitter_gradient, emitter_gradient);
}

@fragment
fn vkf_flare_fragment(input: FlareVertexOut) -> @location(0) vec4<f32> {
  let radius = length(input.local_position);
  if (radius > 1.0 || input.enabled <= 0.0) {
    discard;
  }
  let radial_gradient = 1.0 - smoothstep(0.0, 1.0, radius);
  let halo = radial_gradient * radial_gradient *
    input.bloom_strength * 0.75;
  let bloom_color = vkf_safe_normalize(max(
    input.emitted_radiance, vec3<f32>(1.0e-6)));
  let alpha = clamp(halo, 0.0, 1.0);
  let color = bloom_color * halo * 1.35;
  return vec4<f32>(color, alpha);
}
