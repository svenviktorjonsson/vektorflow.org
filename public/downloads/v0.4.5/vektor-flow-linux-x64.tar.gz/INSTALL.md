# Download, run and share

## Start in the browser

[Open the runnable guide](docs/site/guide.md). For releases with a browser compiler,
the site downloads it automatically. Supported programs compile and run on your
device, without a compilation backend.

Unsupported browser capabilities report exact errors; there is no server-side
execution fallback.

## Download the native compiler

Choose once with the page-wide version selector. The matching compiler packages
and checksums appear below.

<!-- release-downloads -->
VKF is unsupported experimental software: expect incomplete diagnostics and
changing APIs. Do not use it for production or run untrusted native VKF programs.

Run the Windows or macOS installer, then open a new terminal. On Debian/Ubuntu,
including Ubuntu under WSL, download the Debian package and run:

```bash
sudo apt install ./vektor-flow-linux-x64.deb
```

Use the `.deb` download with `apt`, not `vektor-flow-linux-x64.tar.gz`. The
`.tar.gz` file is the portable archive: extract it and run its `./install.sh`
as your normal user, **not with sudo**. Make sure its command directory is on
`PATH`.
The installed compilation path does not require Python, a C++ compiler, an
assembler or a separate linker. Building VKF itself from source is different.

## Your first local program

Check the installed version and evaluate an expression:

```bash
vkf -v
vkf -e ':: "hello, world"'
```

Save this as `hello.vkf`:

```vkf
:: "hello, world"
```

Then build and run it:

```bash
vkf hello.vkf
```

## CLI walkthrough

| Command | What it does |
| --- | --- |
| `vkf program.vkf` | Build when changed, then run. |
| `vkf program.vkf -o app` | Build or reuse the named executable, then run. |
| `vkf -b program.vkf` | Build without running. |
| `vkf -b program.vkf -o app` | Build only, with an explicit output name. |
| `vkf -e ':: 2 + 2'` | Evaluate inline source. |
| `vkf -t tests.vkf` | Run the native tests in a file. |
| `vkf -t tests` | Run the native tests in a directory. |
| `vkf -v` | Print the compiler version. |

`-b` means build, `-e` evaluate, `-t` test, `-v` version and `-o` output.
Passing a source file is the run command; there is no `-r`.
Source, imports, target, compiler and output choice contribute to the build
fingerprint, so unchanged programs can reuse their executable.

The native compiler emits platform executables: PE on Windows, ELF on Linux and
Mach-O on macOS. A build command is not a promise of cross-compilation to every
other platform. [Testing guide](TESTING.md) and [VS Code integration](vscode/README.md).

## Compile the browser runtime from source

This is the contributor path used by the Pages build, **not a public
`vkf --wasm` export command**.

In a source checkout, with the Windows native-build prerequisites available:

```powershell
./scripts/build-native-compiler.ps1 `
  -OutputDirectory build/pages-compiler/bin `
  -OnlyTargets vkf-strict,vkf_symbolic_kernel_artifact
$env:VKF_NATIVE_BIN = (Resolve-Path build/pages-compiler/bin)
npm run build:browser-compiler
node --test tests/bootstrap/browser-compiler-wasm.test.mjs
node tools/build-pages-readme.mjs --output=web/generated
```

The build must pass before publishing. The
[Pages workflow](https://github.com/svenviktorjonsson/vektor-flow/blob/main/.github/workflows/pages.yml) is the complete build recipe;
[the browser architecture](docs/adr/0004-browser-symbolic-kernel.md) explains the
VKF-to-WASM runtime path.

## Host it without an application backend

Serve the generated `web/` directory on a static HTTPS host, preserving its
subdirectories. Serve `.wasm` as `application/wasm` and `.mjs` as JavaScript.
No VKF compilation service is needed: the browser loads the shipped runtime
and executes supported source locally.

For local testing, use an HTTP static-file server rather than opening
`index.html` as a `file://` URL. The Web Worker and module paths must remain
same-origin and accessible. The existing GitHub Pages workflow publishes this
same directory to vektorflow.org.

Native HTML/CSS applications and the browser examples have different capability
boundaries. Native code runs with your user permissions; browser execution
intentionally excludes filesystem, process and network access from user programs.

## Embed VKF in your own webpage

[Build the browser bundle and connect it to HTML/CSS](docs/site/browser.md)
without a compilation backend.

[Return to the guide](docs/site/guide.md).
